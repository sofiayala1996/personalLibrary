class Libro{
    constructor(titulo, autor, año, genero, calificacion) {
        this.titulo = titulo;
        this.autor   = autor;
        this.año  = año;
        this.genero = genero;
        this.calificacion = calificacion;
    }
    mostrarLibro() {
        return `Titulo: ${this.titulo} Autor: ${this.autor} Año: ${this.año} Género: ${this.genero} Calificación: ${this.calificacion}`
    }
}
//Libros pre-guardados
const libro1 = new Libro("Rayuela ", "Julio Cortazar", 1963, "novela", "4");
const libro2 = new Libro("IT ", "Stephen King", 1986, "terror", "5");
const libro3 = new Libro("Harry Potter y la camara secreta ", "J. K. Rowling", 1997, "fantasia", "3");
const libro4 = new Libro("Crepusculo ", "Stephenie Meyer", 2005, "fantasia", "1");

const Libros = [libro1, libro2, libro3, libro4];
//Almacenar libros en localStorage
const guardarLocal = (clave, valor) => {localStorage.setItem(clave, valor) }; 
if(
    ! localStorage.getItem("librosAlmacenados")
){
    guardarLocal("librosAlmacenados", JSON.stringify(Libros));
}
//Mostrar libros disponibles
function mostrandoLibros(){
    const save = localStorage.getItem("librosAlmacenados");
    const change = JSON.parse(save);
    const librosTitulo = change.map((el) => el.titulo);
    const probando = document.getElementById("disponibles");
    probando.innerHTML = "";
    for (const libro of librosTitulo) {
        let li = document.createElement("li");
        li.innerHTML = libro
        probando.appendChild(li);
    }
}
mostrandoLibros();

function mostrarGenero(genero){
    const save = localStorage.getItem("librosAlmacenados");
    const change = JSON.parse(save);
    const libroGenero = change.filter(libro => libro.genero === genero);
    const contenedor = document.getElementById("libroGenero");
    for (const libro of libroGenero){
        let li = document.createElement("li");
        li.innerHTML = libro.titulo;
        li.className = "test";
        contenedor.innerHTML = "";
        contenedor.appendChild(li);
    }
}

document.getElementById("novela").addEventListener("click", function(){mostrarGenero("novela")});
document.getElementById("terror").addEventListener("click", function(){mostrarGenero("terror")});
document.getElementById("fantasia").addEventListener("click", function(){mostrarGenero("fantasia")});
document.getElementById("drama").addEventListener("click", function(){mostrarGenero("drama")});
document.getElementById("otro").addEventListener("click", function(){mostrarGenero("otro")});

//Ingresar libro nuevo
document.getElementById("formulario").addEventListener("submit" , agregarLibro);
document.querySelector("#btn").addEventListener('click', () => {
    Toastify({
        text: "Libro añadido",
        duration: 2000
    }).showToast();
})

function agregarLibro(e){
    e.preventDefault();
    let formulario = e.target;
    //Obtener elementos del formulario
    let titulo = document.getElementById("inputTitulo").value;
    let autor = document.getElementById("inputAutor").value;
    let año = document.getElementById("inputAnio").value;
    let genero = document.getElementById("inputGenero").value;
    let calificacion = document.getElementById("inputCalificacion").value;
    //Sumarlos al array Libros
    Libros.push(new Libro(titulo, autor, año, genero, calificacion));
    //Actualizar la 'base de datos'
    const actualizar = (clave, valor) => {localStorage.setItem(clave, valor) }; 
    actualizar("librosAlmacenados", JSON.stringify(Libros));
    mostrandoLibros();
}

const API_URL = 'http://jsonplaceholder.typicode.com';
const HTMLResponse = document.querySelector("#testingAPI");
const ul = document.createElement("ul");

fetch(`${API_URL}/albums`)
    .then((response) => response.json())
    .then((albums)=>{
        albums.forEach((album) =>{
            let elem = document.createElement("li");
            elem.appendChild(
                document.createTextNode(`${album.title}`)
            );
            ul.appendChild(elem);
        });
        HTMLResponse.appendChild(ul);
    });


